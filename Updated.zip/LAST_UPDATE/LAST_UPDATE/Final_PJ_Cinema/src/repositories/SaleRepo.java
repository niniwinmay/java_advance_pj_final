package repositories;

public interface SaleRepo {

}
