package entities;

public enum UserRole {
	ADMIN, STAFF, MANAGER
}
