package shared.utils;

import entities.Employee;
import entities.UserRole;

public class CurrentUserHolder {

	private static Employee employee;
	 static UserRole role;
	
	private CurrentUserHolder() {}
	
	public static Employee getCurrentUser() {
		return employee;
	}
	
	public static UserRole getRole() {
		return role.ADMIN;
	}
	public static void setLoggedInUser(Employee employee) {
		CurrentUserHolder.employee = employee;
	}
}
