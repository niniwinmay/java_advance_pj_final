package shared.exception;

import javax.swing.*;

public class AppException extends  RuntimeException{

    public AppException(String message) {
        super(message);
    }

}
