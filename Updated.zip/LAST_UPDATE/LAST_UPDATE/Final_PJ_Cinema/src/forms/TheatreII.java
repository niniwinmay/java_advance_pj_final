package forms;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import entities.ScheduleDetail;
import entities.Seat;
import entities.SeatDetail;
import entities.Ticket;
import services.SeatDetailService;
import services.SeatService;
import services.TicketService;

public class TheatreII {

	public JFrame frameTheatreII;
	List<String> seatList= new ArrayList<>();
	ScheduleDetail scheduleDetail;
	SeatService seatService;
	TicketService ticketService;
	SeatDetailService seatDetailService;
	SeatDetail seatDetail;
	String theatreId;
	List<Ticket> ticketList = new ArrayList<>();
	Seat seat;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TheatreII window = new TheatreII();
					window.frameTheatreII.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TheatreII() {
		initialize();
	}
	
	public TheatreII(ScheduleDetail scheduleDetail) {
		this.seatService = new SeatService();
		this.ticketService = new TicketService();
		this.seatDetailService = new SeatDetailService();
		this.scheduleDetail = scheduleDetail;
		this.theatreId = scheduleDetail.getSchedule().getTheatre().getTheatre_id()+"";
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frameTheatreII = new JFrame();
		frameTheatreII.getContentPane().setBackground(new Color(176, 196, 222));
		frameTheatreII.setTitle("TheatreII");
		frameTheatreII.setBounds(100, 100, 707, 568);
		frameTheatreII.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameTheatreII.getContentPane().setLayout(null);

		JButton btnA01 = new JButton("A01");
		btnA01.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("A01");
				seat=seatService.findSeatByName(btnA01.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnA01.setEnabled(false);
			}
		});
		btnA01.setBackground(Color.ORANGE);
		btnA01.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnA01.setBounds(22, 272, 65, 21);
		frameTheatreII.getContentPane().add(btnA01);

		JButton btnA02 = new JButton("A02");
		btnA02.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("A02");
				seat=seatService.findSeatByName(btnA02.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnA02.setEnabled(false);
			}
		});
		btnA02.setBackground(Color.ORANGE);
		btnA02.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnA02.setBounds(92, 272, 65, 21);
		frameTheatreII.getContentPane().add(btnA02);

		JButton btnA03 = new JButton("A03");
		btnA03.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("A03");
				seat=seatService.findSeatByName(btnA03.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnA03.setEnabled(false);
			}
		});
		btnA03.setBackground(Color.ORANGE);
		btnA03.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnA03.setBounds(165, 272, 65, 21);
		frameTheatreII.getContentPane().add(btnA03);

		JButton btnA04 = new JButton("A04");
		btnA04.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("A04");
				seat=seatService.findSeatByName(btnA04.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnA04.setEnabled(false);
			}
		});
		btnA04.setBackground(Color.ORANGE);
		btnA04.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnA04.setBounds(235, 272, 65, 21);
		frameTheatreII.getContentPane().add(btnA04);

		JButton btnA05 = new JButton("A05");
		btnA05.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("A05");
				seat=seatService.findSeatByName(btnA05.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnA05.setEnabled(false);
			}
		});
		btnA05.setBackground(Color.ORANGE);
		btnA05.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnA05.setBounds(399, 272, 65, 21);
		frameTheatreII.getContentPane().add(btnA05);

		JButton btnA06 = new JButton("A06");
		btnA06.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("A06");
				seat=seatService.findSeatByName(btnA06.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnA06.setEnabled(false);
			}
		});
		btnA06.setBackground(Color.ORANGE);
		btnA06.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnA06.setBounds(469, 272, 65, 21);
		frameTheatreII.getContentPane().add(btnA06);

		JButton btnA07 = new JButton("A07");
		btnA07.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("A07");
				seat=seatService.findSeatByName(btnA07.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnA07.setEnabled(false);
			}
		});
		btnA07.setBackground(Color.ORANGE);
		btnA07.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnA07.setBounds(539, 272, 64, 21);
		frameTheatreII.getContentPane().add(btnA07);

		JButton btnA08 = new JButton("A08");
		btnA08.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("A08");
				seat=seatService.findSeatByName(btnA08.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnA08.setEnabled(false);
			}
		});
		btnA08.setBackground(Color.ORANGE);
		btnA08.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnA08.setBounds(605, 272, 65, 21);
		frameTheatreII.getContentPane().add(btnA08);

		JButton btnB01 = new JButton("B01");
		btnB01.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("B01");
				seat=seatService.findSeatByName(btnB01.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnB01.setEnabled(false);
			}
		});
		btnB01.setBackground(Color.GREEN);
		btnB01.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnB01.setBounds(22, 315, 65, 21);
		frameTheatreII.getContentPane().add(btnB01);

		JButton btnB02 = new JButton("B02");
		btnB02.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("B02");
				seat=seatService.findSeatByName(btnB02.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnB02.setEnabled(false);
			}
		});
		btnB02.setBackground(Color.GREEN);
		btnB02.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnB02.setBounds(92, 315, 65, 21);
		frameTheatreII.getContentPane().add(btnB02);

		JButton btnB03 = new JButton("B03");
		btnB03.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("B03");
				seat=seatService.findSeatByName(btnB03.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnB03.setEnabled(false);
			}
		});
		btnB03.setBackground(Color.GREEN);
		btnB03.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnB03.setBounds(165, 315, 65, 21);
		frameTheatreII.getContentPane().add(btnB03);

		JButton btnB04 = new JButton("B04");
		btnB04.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("B04");
				seat=seatService.findSeatByName(btnB04.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnB04.setEnabled(false);
			}
		});
		btnB04.setBackground(Color.GREEN);
		btnB04.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnB04.setBounds(235, 315, 65, 21);
		frameTheatreII.getContentPane().add(btnB04);

		JButton btnB05 = new JButton("B05");
		btnB05.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("B05");
				seat=seatService.findSeatByName(btnB05.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnB05.setEnabled(false);
			}
		});
		btnB05.setBackground(Color.GREEN);
		btnB05.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnB05.setBounds(399, 315, 65, 21);
		frameTheatreII.getContentPane().add(btnB05);

		JButton btnB06 = new JButton("B06");
		btnB06.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("B06");
				seat=seatService.findSeatByName(btnB06.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnB06.setEnabled(false);
			}
		});
		btnB06.setBackground(Color.GREEN);
		btnB06.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnB06.setBounds(469, 315, 65, 21);
		frameTheatreII.getContentPane().add(btnB06);

		JButton btnB07 = new JButton("B07");
		btnB07.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("B07");
				seat=seatService.findSeatByName(btnB07.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnB07.setEnabled(false);
			}
		});
		btnB07.setBackground(Color.GREEN);
		btnB07.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnB07.setBounds(542, 315, 61, 21);
		frameTheatreII.getContentPane().add(btnB07);

		JButton btnB08 = new JButton("B08");
		btnB08.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("B08");
				seat=seatService.findSeatByName(btnB08.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnB08.setEnabled(false);
			}
		});
		btnB08.setBackground(Color.GREEN);
		btnB08.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnB08.setBounds(605, 315, 65, 21);
		frameTheatreII.getContentPane().add(btnB08);

		JButton btnC01 = new JButton("C01");
		btnC01.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("C01");
				seat=seatService.findSeatByName(btnC01.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnC01.setEnabled(false);
			}
		});
		btnC01.setBackground(Color.CYAN);
		btnC01.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnC01.setBounds(22, 362, 65, 21);
		frameTheatreII.getContentPane().add(btnC01);

		JButton btnC02 = new JButton("C02");
		btnC02.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("C02");
				seat=seatService.findSeatByName(btnC02.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnC02.setEnabled(false);
			}
		});
		btnC02.setBackground(Color.CYAN);
		btnC02.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnC02.setBounds(92, 362, 65, 21);
		frameTheatreII.getContentPane().add(btnC02);

		JButton btnC03 = new JButton("C03");
		btnC03.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("C03");
				seat=seatService.findSeatByName(btnC03.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnC03.setEnabled(false);
			}
		});
		btnC03.setBackground(Color.CYAN);
		btnC03.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnC03.setBounds(165, 362, 65, 21);
		frameTheatreII.getContentPane().add(btnC03);

		JButton btnC04 = new JButton("C04");
		btnC04.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("C04");
				seat=seatService.findSeatByName(btnC04.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnC04.setEnabled(false);
			}
		});
		btnC04.setBackground(Color.CYAN);
		btnC04.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnC04.setBounds(235, 362, 65, 21);
		frameTheatreII.getContentPane().add(btnC04);

		JButton btnC05 = new JButton("C05");
		btnC05.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("C05");
				seat=seatService.findSeatByName(btnC05.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnC05.setEnabled(false);
			}
		});
		btnC05.setBackground(Color.CYAN);
		btnC05.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnC05.setBounds(399, 362, 65, 21);
		frameTheatreII.getContentPane().add(btnC05);

		JButton btnC06 = new JButton("C06");
		btnC06.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("C06");
				seat=seatService.findSeatByName(btnC06.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnC06.setEnabled(false);
			}
		});
		btnC06.setBackground(Color.CYAN);
		btnC06.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnC06.setBounds(469, 362, 65, 21);
		frameTheatreII.getContentPane().add(btnC06);

		JButton btnC07 = new JButton("C07");
		btnC07.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("C07");
				seat=seatService.findSeatByName(btnC07.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnC07.setEnabled(false);
			}
		});
		btnC07.setBackground(Color.CYAN);
		btnC07.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnC07.setBounds(542, 362, 61, 21);
		frameTheatreII.getContentPane().add(btnC07);

		JButton btnC08 = new JButton("C08");
		btnC08.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("C08");
				seat=seatService.findSeatByName(btnC08.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnC08.setEnabled(false);
			}
		});
		btnC08.setBackground(Color.CYAN);
		btnC08.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnC08.setBounds(605, 362, 65, 21);
		frameTheatreII.getContentPane().add(btnC08);

		JButton btnD01 = new JButton("D01");
		btnD01.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("D01");
				seat=seatService.findSeatByName(btnD01.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnD01.setEnabled(false);
			}
		});
		btnD01.setBackground(new Color(255, 0, 255));
		btnD01.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnD01.setBounds(22, 402, 65, 21);
		frameTheatreII.getContentPane().add(btnD01);

		JButton btnD02 = new JButton("D02");
		btnD02.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("D02");
				seat=seatService.findSeatByName(btnD02.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnD02.setEnabled(false);
			}
		});
		btnD02.setBackground(new Color(255, 0, 255));
		btnD02.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnD02.setBounds(92, 402, 65, 21);
		frameTheatreII.getContentPane().add(btnD02);

		JButton btnD03 = new JButton("D03");
		btnD03.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("D03");
				seat=seatService.findSeatByName(btnD03.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnD03.setEnabled(false);
			}
		});
		btnD03.setBackground(new Color(255, 0, 255));
		btnD03.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnD03.setBounds(165, 402, 65, 21);
		frameTheatreII.getContentPane().add(btnD03);

		JButton btnD04 = new JButton("D04");
		btnD04.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("D04");
				seat=seatService.findSeatByName(btnD04.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnD04.setEnabled(false);
			}
		});
		btnD04.setBackground(new Color(255, 0, 255));
		btnD04.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnD04.setBounds(235, 402, 65, 21);
		frameTheatreII.getContentPane().add(btnD04);

		JButton btnD05 = new JButton("D05");
		btnD05.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("D05");
				seat=seatService.findSeatByName(btnD05.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnD05.setEnabled(false);
			}
		});
		btnD05.setBackground(new Color(255, 0, 255));
		btnD05.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnD05.setBounds(399, 402, 65, 21);
		frameTheatreII.getContentPane().add(btnD05);

		JButton btnD06 = new JButton("D06");
		btnD06.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("D06");
				seat=seatService.findSeatByName(btnD06.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnD06.setEnabled(false);
			}
		});
		btnD06.setBackground(new Color(255, 0, 255));
		btnD06.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnD06.setBounds(469, 402, 65, 21);
		frameTheatreII.getContentPane().add(btnD06);

		JButton btnD07 = new JButton("D07");
		btnD07.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("D07");
				seat=seatService.findSeatByName(btnD07.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnD07.setEnabled(false);
			}
		});
		btnD07.setBackground(new Color(255, 0, 255));
		btnD07.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnD07.setBounds(542, 402, 61, 21);
		frameTheatreII.getContentPane().add(btnD07);

		JButton btnD08 = new JButton("D08");
		btnD08.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("D08");
				seat=seatService.findSeatByName(btnD08.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnD08.setEnabled(false);
			}
		});
		btnD08.setBackground(new Color(255, 0, 255));
		btnD08.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnD08.setBounds(605, 402, 65, 21);
		frameTheatreII.getContentPane().add(btnD08);

		JButton btnE01 = new JButton("E01");
		btnE01.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("E01");
				seat=seatService.findSeatByName(btnE01.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnE01.setEnabled(false);
			}
		});
		btnE01.setBackground(new Color(0, 153, 153));
		btnE01.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnE01.setBounds(42, 444, 95, 21);
		frameTheatreII.getContentPane().add(btnE01);

		JButton btnE02 = new JButton("E02");
		btnE02.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("E02");
				seat=seatService.findSeatByName(btnE02.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnE02.setEnabled(false);
			}
		});
		btnE02.setBackground(new Color(0, 153, 153));
		btnE02.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnE02.setBounds(185, 444, 95, 21);
		frameTheatreII.getContentPane().add(btnE02);

		JButton btnE03 = new JButton("E03");
		btnE03.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("E03");
				seat=seatService.findSeatByName(btnE03.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnE03.setEnabled(false);
			}
		});
		btnE03.setBackground(new Color(0, 153, 153));
		btnE03.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnE03.setBounds(422, 444, 95, 21);
		frameTheatreII.getContentPane().add(btnE03);

		JButton btnE04 = new JButton("E04");
		btnE04.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seatList.add("E04");
				seat=seatService.findSeatByName(btnE04.getText());
				createTicket();
				ticketList.add(ticketService.getlatestTicket());
				btnE04.setEnabled(false);
			}
		});
		btnE04.setBackground(new Color(0, 153, 153));
		btnE04.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnE04.setBounds(564, 444, 89, 21);
		frameTheatreII.getContentPane().add(btnE04);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 0));
		panel.setForeground(new Color(240, 255, 255));
		panel.setBounds(22, 10, 648, 193);
		frameTheatreII.getContentPane().add(panel);
		panel.setLayout(null);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(25, 23, 595, 146);
		panel.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel = new JLabel("Welcome To Our Cinema");
		lblNewLabel.setForeground(new Color(255, 0, 0));
		lblNewLabel.setBounds(180, 58, 296, 19);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		panel_1.add(lblNewLabel);

		JLabel lblTheatre2 = new JLabel("Theatre II");
		lblTheatre2.setForeground(Color.RED);
		lblTheatre2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblTheatre2.setBounds(244, 29, 149, 19);
		panel_1.add(lblTheatre2);

		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SaleVoucherForm saleVoucher = new SaleVoucherForm(seatList,ticketList);
				saleVoucher.frameVoucher.setVisible(true);
			}
		});
		btnSave.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnSave.setBounds(241, 486, 91, 21);
		frameTheatreII.getContentPane().add(btnSave);

		JButton btnCancel = new JButton("Cancel");
		btnCancel.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnCancel.setBounds(350, 486, 91, 21);
		frameTheatreII.getContentPane().add(btnCancel);
	}
	public void createTicket() {
		seatDetail =seatDetailService.findBySeatDetailBySeatTheatre(seat.getSeat_id()+"",theatreId);
		Ticket ticket = new Ticket();
		ticket.setSeatDetail(seatDetail);;
		ticket.setScheduleDetail(scheduleDetail);
		ticket.setStatus("Sold");
		ticket.setDate(setSaleDate());
		ticketService.createTicket(ticket);
	}
	
	public String setSaleDate() {
		 SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
		 Date date = new Date(); 
		 return formatter.format(date);
	}

}
